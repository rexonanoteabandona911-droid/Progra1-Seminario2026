﻿namespace Conversor_de_Area_El_Salvador
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtCantidad = new TextBox();
            De = new Label();
            label3 = new Label();
            cboDe = new ComboBox();
            cboA = new ComboBox();
            btnCalcular = new Button();
            btnSalir = new Button();
            lblRespuesta = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(163, 71);
            label1.Name = "label1";
            label1.Size = new Size(67, 20);
            label1.TabIndex = 0;
            label1.Text = "cantidad";
            // 
            // txtCantidad
            // 
            txtCantidad.Location = new Point(163, 94);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(125, 27);
            txtCantidad.TabIndex = 1;
            // 
            // De
            // 
            De.AutoSize = true;
            De.Location = new Point(165, 172);
            De.Name = "De";
            De.Size = new Size(31, 20);
            De.TabIndex = 2;
            De.Text = "De:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(445, 172);
            label3.Name = "label3";
            label3.Size = new Size(22, 20);
            label3.TabIndex = 3;
            label3.Text = "A:";
            // 
            // cboDe
            // 
            cboDe.FormattingEnabled = true;
            cboDe.Items.AddRange(new object[] { "a. Pie Cuadrado", "", "", "", "b. Vara Cuadrada", "", "", "", "c. Yarda Cuadrada", "", "", "", "d. Metro Cuadrado", "", "", "", "e. Tareas", "", "", "", "f. Manzana", "", "", "", "g. Hectárea" });
            cboDe.Location = new Point(173, 214);
            cboDe.Name = "cboDe";
            cboDe.Size = new Size(151, 28);
            cboDe.TabIndex = 4;
            // 
            // cboA
            // 
            cboA.FormattingEnabled = true;
            cboA.Items.AddRange(new object[] { "a. Pie Cuadrado", "", "", "", "b. Vara Cuadrada", "", "", "", "c. Yarda Cuadrada", "", "", "", "d. Metro Cuadrado", "", "", "", "e. Tareas", "", "", "", "f. Manzana", "", "", "", "g. Hectárea" });
            cboA.Location = new Point(445, 214);
            cboA.Name = "cboA";
            cboA.Size = new Size(151, 28);
            cboA.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(270, 274);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(94, 29);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(401, 274);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(94, 29);
            btnSalir.TabIndex = 7;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // lblRespuesta
            // 
            lblRespuesta.Location = new Point(173, 366);
            lblRespuesta.Name = "lblRespuesta";
            lblRespuesta.Size = new Size(125, 27);
            lblRespuesta.TabIndex = 9;
            lblRespuesta.Text = "Respuesta:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblRespuesta);
            Controls.Add(btnSalir);
            Controls.Add(btnCalcular);
            Controls.Add(cboA);
            Controls.Add(cboDe);
            Controls.Add(label3);
            Controls.Add(De);
            Controls.Add(txtCantidad);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtCantidad;
        private Label De;
        private Label label3;
        private ComboBox cboDe;
        private ComboBox cboA;
        private Button btnCalcular;
        private Button btnSalir;
        private TextBox lblRespuesta;
    }
}
