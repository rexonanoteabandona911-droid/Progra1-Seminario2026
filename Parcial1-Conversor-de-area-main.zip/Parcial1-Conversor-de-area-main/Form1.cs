namespace Conversor_de_Area_El_Salvador
{
    public partial class Form1 : Form
    {
        private readonly string[] etiquetas = {
            "Pie Cuadrado",
            "Vara Cuadrada",
            "Yarda Cuadrada",
            "Metro Cuadrado",
            "Tareas",
            "Manzana",
            "Hectárea"
        };

        private readonly double[] valores = {
            0.09290304,
            0.698896,
            0.83612736,
            1.0,
            628.86,
            6988.96,
            10000.0
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Cargar directamente las unidades de área en los ComboBox
            cboDe.Items.Clear();
            cboA.Items.Clear();

            cboDe.Items.AddRange(etiquetas);
            cboA.Items.AddRange(etiquetas);

            // Seleccionar opciones por defecto (ejemplo: Vara Cuadrada a Metro Cuadrado)
            cboDe.SelectedIndex = 1; // Vara Cuadrada
            cboA.SelectedIndex = 3;  // Metro Cuadrado
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (cboDe.SelectedIndex == -1 || cboA.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecciona las unidades de origen y destino.");
                return;
            }

            if (double.TryParse(txtCantidad.Text, out double cantidad))
            {
                if (cantidad < 0)
                {
                    MessageBox.Show("Ingresa una cantidad mayor o igual a cero.");
                    return;
                }

                int de = cboDe.SelectedIndex;
                int a = cboA.SelectedIndex;

                double valorEnMetros = cantidad * valores[de];
                double resultado = valorEnMetros / valores[a];

                lblRespuesta.Text = "Respuesta: " + resultado.ToString("N4") + " " + etiquetas[a];
            }
            else
            {
                MessageBox.Show("Ingresa una cantidad numérica válida.");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

