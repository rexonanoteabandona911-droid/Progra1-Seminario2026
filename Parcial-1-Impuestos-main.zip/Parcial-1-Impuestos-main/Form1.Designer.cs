﻿namespace Impuestos_a_las_actividades_economicas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtMonto = new TextBox();
            label3 = new Label();
            txtResultado = new TextBox();
            btnCalcular = new Button();
            btnSalir = new Button();
            txtDesarrollo = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(165, 55);
            label1.Name = "label1";
            label1.Size = new Size(414, 20);
            label1.TabIndex = 0;
            label1.Text = "IMPUESTOS A LA ECONOMIAS ECONOMICAS (EL SALVADOR)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(163, 108);
            label2.Name = "label2";
            label2.Size = new Size(215, 20);
            label2.TabIndex = 1;
            label2.Text = "Monto Actividad Economica($)";
            // 
            // txtMonto
            // 
            txtMonto.Location = new Point(397, 108);
            txtMonto.Name = "txtMonto";
            txtMonto.Size = new Size(125, 27);
            txtMonto.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(163, 148);
            label3.Name = "label3";
            label3.Size = new Size(153, 20);
            label3.TabIndex = 3;
            label3.Text = "Resultado (A pagar$):";
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(397, 141);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(125, 27);
            txtResultado.TabIndex = 4;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(175, 226);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(94, 29);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "CALCULAR";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(337, 226);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(94, 29);
            btnSalir.TabIndex = 6;
            btnSalir.Text = "SALIR";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // txtDesarrollo
            // 
            txtDesarrollo.Location = new Point(165, 277);
            txtDesarrollo.Name = "txtDesarrollo";
            txtDesarrollo.Size = new Size(399, 27);
            txtDesarrollo.TabIndex = 7;
            txtDesarrollo.Text = "Desarrollo";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtDesarrollo);
            Controls.Add(btnSalir);
            Controls.Add(btnCalcular);
            Controls.Add(txtResultado);
            Controls.Add(label3);
            Controls.Add(txtMonto);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtMonto;
        private Label label3;
        private TextBox txtResultado;
        private Button btnCalcular;
        private Button btnSalir;
        private TextBox txtDesarrollo;
    }
}
