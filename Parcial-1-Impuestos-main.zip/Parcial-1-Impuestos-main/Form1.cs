using System;
using System.Windows.Forms;

namespace Impuestos_a_las_actividades_economicas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            decimal limiteInferior = 1000.01m;
            decimal cuotaFija = 3.0m;
            decimal cuotaMillar = 3.0m;

            if (!decimal.TryParse(txtMonto.Text, out decimal monto))
            {
                MessageBox.Show("Por favor, ingrese un monto válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal impuestoTotal;
            if (monto > limiteInferior)
            {
                decimal excedente = monto - limiteInferior;
                impuestoTotal = (excedente / 1000m * cuotaMillar) + cuotaFija;
            }
            else
            {
                impuestoTotal = cuotaFija;
            }

            txtDesarrollo.Text = $"$ {impuestoTotal:N2}";
            txtDesarrollo.Text = $"Desarrollo: ({monto:N2} - {limiteInferior:N2}) / 1000 * {cuotaMillar:N2} + {cuotaFija:N2} = {impuestoTotal:N2}";
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}



