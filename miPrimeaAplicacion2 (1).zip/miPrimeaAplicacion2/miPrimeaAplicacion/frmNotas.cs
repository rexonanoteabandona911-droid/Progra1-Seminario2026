﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miPrimeaAplicacion
{
    public partial class frmNotas : Form
    {
        Conexion objConexion = new Conexion();
        DataSet objNotas = new DataSet();
        bool cargado = false;

        public frmNotas()
        {
            InitializeComponent();
        }
        private void frmNotas_Load(object sender, EventArgs e)
        {
            try
            {
                cargado = false;

                // 1. Cargar ComboBox de Materias
                string sqlMaterias = "SELECT * FROM materias";
                DataSet dsMaterias = objConexion.obtenerDatos(sqlMaterias);
                if (dsMaterias != null && dsMaterias.Tables.Count > 0)
                {
                    dsMaterias.EnforceConstraints = false;
                    cboMateria.DataSource = dsMaterias.Tables[0];
                    cboMateria.ValueMember = dsMaterias.Tables[0].Columns[0].ColumnName;
                    cboMateria.DisplayMember = dsMaterias.Tables[0].Columns[1].ColumnName;
                    cboMateria.SelectedIndex = -1;
                }

                // 2. Cargar ComboBox de Períodos
                string sqlPeriodos = "SELECT * FROM periodos";
                DataSet dsPeriodos = objConexion.obtenerDatos(sqlPeriodos);
                if (dsPeriodos != null && dsPeriodos.Tables.Count > 0)
                {
                    dsPeriodos.EnforceConstraints = false;
                    cboPeriodo.DataSource = dsPeriodos.Tables[0];
                    cboPeriodo.ValueMember = dsPeriodos.Tables[0].Columns[0].ColumnName;
                    cboPeriodo.DisplayMember = dsPeriodos.Tables[0].Columns[1].ColumnName;
                    cboPeriodo.SelectedIndex = -1;
                }

                cargado = true;

                if (cboMateria.Items.Count > 0) cboMateria.SelectedIndex = 0;
                if (cboPeriodo.Items.Count > 0) cboPeriodo.SelectedIndex = 0;

                actualizarGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos iniciales: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void actualizarDs()
        {
            try
            {
                int idMateria = 0;
                int idPeriodo = 0;

                // Validar de forma segura el valor de la materia
                if (cboMateria != null && cboMateria.SelectedValue != null)
                {
                    int.TryParse(cboMateria.SelectedValue.ToString(), out idMateria);
                }

                // Validar de forma segura el valor del período
                if (cboPeriodo != null && cboPeriodo.SelectedValue != null)
                {
                    int.TryParse(cboPeriodo.SelectedValue.ToString(), out idPeriodo);
                }

                // Si los combos aún no cargaron, evitamos que falle la consulta poniendo 0
                string sql = @"SELECT a.idAlumno AS ID, 
                              a.nombre AS ALUMNO, 
                              ISNULL(d.lab1, 0) AS LAB1, 
                              ISNULL(d.lab2, 0) AS LAB2, 
                              ISNULL(d.parcial, 0) AS PARCIAL,
                              CAST((ISNULL(d.lab1, 0) * 0.3 + ISNULL(d.lab2, 0) * 0.3 + ISNULL(d.parcial, 0) * 0.4) AS DECIMAL(10,2)) AS [NOTA FINAL],
                              ISNULL(d.idDetalle, 0) AS idDetalle,
                              ISNULL(n.idNota, 0) AS idNota
                       FROM alumnos a
                       LEFT JOIN notas n ON a.idAlumno = n.idAlumno AND n.idPeriodo = " + idPeriodo + @"
                       LEFT JOIN dnotas d ON n.idNota = d.idNota AND d.idMateria = " + idMateria;

                objNotas = objConexion.obtenerDatos(sql);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void actualizarGrid()
        {
            actualizarDs();
            if (objNotas != null && objNotas.Tables.Count > 0)
            {
                dnotasDataGridView.DataSource = objNotas.Tables[0];

                // Ocultar columnas técnicas internas para mantener limpia la interfaz
                if (dnotasDataGridView.Columns.Contains("idDetalle")) dnotasDataGridView.Columns["idDetalle"].Visible = false;
                if (dnotasDataGridView.Columns.Contains("idNota")) dnotasDataGridView.Columns["idNota"].Visible = false;
                if (dnotasDataGridView.Columns.Contains("ID")) dnotasDataGridView.Columns["ID"].ReadOnly = true;
                if (dnotasDataGridView.Columns.Contains("ALUMNO")) dnotasDataGridView.Columns["ALUMNO"].ReadOnly = true;
                if (dnotasDataGridView.Columns.Contains("NOTA FINAL")) dnotasDataGridView.Columns["NOTA FINAL"].ReadOnly = true;

                // IMPORTANTE: Asegúrate de que tu DataGridView NO tenga la propiedad SelectionMode en FullRowSelect, 
                // de lo contrario no podrás editar las celdas de las notas. Debe estar en RowHeaderSelect o CellSelect.
            }
        }

        private void cboMateria_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cargado)
            {
                actualizarGrid();
            }
        }

        private void cboPeriodo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cargado)
            {
                actualizarGrid();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (cboMateria.SelectedValue == null || cboPeriodo.SelectedValue == null)
            {
                MessageBox.Show("Seleccione una Materia y un Período válidos.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            dnotasDataGridView.EndEdit();

            int idMateria = Convert.ToInt32(cboMateria.SelectedValue);
            int idPeriodo = Convert.ToInt32(cboPeriodo.SelectedValue);
            bool huboErrores = false;

            foreach (DataGridViewRow fila in dnotasDataGridView.Rows)
            {
                if (fila.IsNewRow) continue;

                double lab1 = 0, lab2 = 0, parcial = 0;
                int idDetalle = 0, idNota = 0, idAlumno = 0;

                int.TryParse(fila.Cells["ID"].Value?.ToString() ?? "0", out idAlumno);
                double.TryParse(fila.Cells["LAB1"].Value?.ToString() ?? "0", out lab1);
                double.TryParse(fila.Cells["LAB2"].Value?.ToString() ?? "0", out lab2);
                double.TryParse(fila.Cells["PARCIAL"].Value?.ToString() ?? "0", out parcial);

                int.TryParse(fila.Cells["idDetalle"].Value?.ToString() ?? "0", out idDetalle);
                int.TryParse(fila.Cells["idNota"].Value?.ToString() ?? "0", out idNota);

                string strLab1 = lab1.ToString(CultureInfo.InvariantCulture);
                string strLab2 = lab2.ToString(CultureInfo.InvariantCulture);
                string strParcial = parcial.ToString(CultureInfo.InvariantCulture);

                string sql = "";

                if (idAlumno > 0)
                {
                    if (idNota == 0)
                    {
                        string sqlCheck = $"SELECT ISNULL(MAX(idNota), 0) FROM notas WHERE idAlumno = {idAlumno} AND idPeriodo = {idPeriodo}";
                        DataSet dsCheck = objConexion.obtenerDatos(sqlCheck);
                        if (dsCheck != null && dsCheck.Tables.Count > 0 && dsCheck.Tables[0].Rows.Count > 0)
                        {
                            idNota = Convert.ToInt32(dsCheck.Tables[0].Rows[0][0]);
                        }

                        if (idNota == 0)
                        {
                            string sqlInsertNota = $"INSERT INTO notas (idAlumno, idPeriodo) VALUES ({idAlumno}, {idPeriodo})";
                            objConexion.ejecutarSQL(sqlInsertNota);

                            DataSet dsId = objConexion.obtenerDatos(sqlCheck);
                            if (dsId != null && dsId.Tables.Count > 0 && dsId.Tables[0].Rows.Count > 0)
                            {
                                idNota = Convert.ToInt32(dsId.Tables[0].Rows[0][0]);
                            }
                        }
                    }

                    if (idDetalle == 0 && idNota > 0)
                    {
                        string sqlCheckDetalle = $"SELECT ISNULL(MAX(idDetalle), 0) FROM dnotas WHERE idNota = {idNota} AND idMateria = {idMateria}";
                        DataSet dsDetalle = objConexion.obtenerDatos(sqlCheckDetalle);
                        if (dsDetalle != null && dsDetalle.Tables.Count > 0 && dsDetalle.Tables[0].Rows.Count > 0)
                        {
                            idDetalle = Convert.ToInt32(dsDetalle.Tables[0].Rows[0][0]);
                        }
                    }

                    if (idDetalle > 0)
                    {
                        sql = $"UPDATE dnotas SET lab1 = {strLab1}, lab2 = {strLab2}, parcial = {strParcial} WHERE idDetalle = {idDetalle}";
                    }
                    else if (idNota > 0)
                    {
                        sql = $"INSERT INTO dnotas (idNota, idMateria, lab1, lab2, parcial) VALUES ({idNota}, {idMateria}, {strLab1}, {strLab2}, {strParcial})";
                    }
                }

                if (!string.IsNullOrEmpty(sql))
                {
                    string resp = objConexion.ejecutarSQL(sql);
                    if (!string.IsNullOrEmpty(resp) && resp.ToLower().Contains("error"))
                    {
                        MessageBox.Show("Error al guardar la fila del alumno ID " + idAlumno + ": " + resp, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        huboErrores = true;
                        break;
                    }
                }
            }

            if (!huboErrores)
            {
                MessageBox.Show("¡Notas guardadas correctamente!", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                actualizarGrid();
            }
        }

        private void dnotasDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}