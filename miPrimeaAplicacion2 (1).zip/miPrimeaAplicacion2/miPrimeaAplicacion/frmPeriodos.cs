﻿using System;
using System.Data;
using System.Data.SqlClient; 
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miPrimeaAplicacion
{
    public partial class frmPeriodos : Form
    {
        Conexion objConexion = new Conexion();

        public frmPeriodos()
        {
            InitializeComponent();
        }

        private void periodosBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.periodosBindingSource.EndEdit();

                DataTable tablaPeriodos = (DataTable)this.periodosBindingSource.DataSource;
                SqlCommandBuilder constructorComandos = new SqlCommandBuilder(objConexion.objDataAdapter);
                objConexion.objDataAdapter.Update(tablaPeriodos);

                MessageBox.Show("Datos guardados correctamente en la base de datos.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmPeriodos_Load(object sender, EventArgs e)
        {
            CargarDatosPeriodos();

        }

        private void CargarDatosPeriodos()
        {
            try
            {
                string consulta = "SELECT * FROM periodos";
                DataSet ds = objConexion.obtenerDatos(consulta);

                if (ds != null && ds.Tables.Count > 0)
                {
                    ds.EnforceConstraints = false;
                    this.periodosBindingSource.DataSource = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar periodos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}