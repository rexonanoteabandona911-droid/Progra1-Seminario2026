﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data; //Esta libreria es para usar bases de datos
using System.Data.SqlClient; //Esta libreria permite usar SQLServer

namespace miPrimeaAplicacion {
    internal class Conexion {
        //Definir los miembros, atributos y metodos de la clase
        public SqlConnection objConexion = new SqlConnection(); //Conectarme a la BD
        public SqlCommand objComando = new SqlCommand(); //Ejecutar consultas (Insert, update, delete, select) SQL en la BD
        public SqlDataAdapter objDataAdapter = new SqlDataAdapter();//un puente entre la BD y la aplicacion.
        DataSet objDs = new DataSet(); //Representa una copia en memoria de la arquitectura de la BD

        public Conexion()
        {//Constructor e inicializador de los miembros de la clase
            abrirConexion(); //abrir la BD (funciona en cualquier PC)
            crearTablaUsuarios(); //garantiza que exista la tabla de usuarios
        }

        // Conexion portable: no depende del nombre de la PC.
        // Intenta, en orden: 1) adjuntar data\db_academica.mdf con LocalDB (viene con Visual Studio),
        // 2) adjuntarlo con SQL Server Express local, 3) usar la BD db_academica ya existente en SQL Express.
        private void abrirConexion()
        {
            string mdf = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "db_academica.mdf");
            string[] cadenas = {
                @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + mdf + ";Integrated Security=True;Connect Timeout=30",
                @"Data Source=.\SQLEXPRESS;AttachDbFilename=" + mdf + ";Integrated Security=True;TrustServerCertificate=True;Connect Timeout=15",
                @"Data Source=.\SQLEXPRESS;Initial Catalog=db_academica;Integrated Security=True;TrustServerCertificate=True;Connect Timeout=15",
                @"Data Source=(local);Initial Catalog=db_academica;Integrated Security=True;TrustServerCertificate=True;Connect Timeout=15"
            };
            Exception ultimo = null;
            foreach (string cadena in cadenas)
            {
                try
                {
                    objConexion.ConnectionString = cadena;
                    objConexion.Open();
                    return;
                }
                catch (Exception ex)
                {
                    ultimo = ex;
                    objConexion.Close();
                }
            }
            throw new Exception("No se pudo conectar a SQL Server en esta PC. Instale SQL Server Express o LocalDB. Detalle: " + ultimo.Message);
        }

        // Crea la tabla usuarios_usss075826 si aun no existe en la BD (misma estructura que data/script_usuarios.sql)
        private void crearTablaUsuarios()
        {
            string sql = @"IF OBJECT_ID('dbo.usuarios_usss075826', 'U') IS NULL
                CREATE TABLE dbo.usuarios_usss075826 (
                    idUsuario INT IDENTITY(1,1) PRIMARY KEY,
                    usuario   VARCHAR(35) NOT NULL,
                    clave     VARCHAR(35) NOT NULL,
                    nombre    VARCHAR(65) NOT NULL,
                    direccion VARCHAR(85) NULL,
                    telefono  VARCHAR(9)  NULL
                )";
            // Si la tabla ya existia con otra estructura (version anterior), se completa
            sql += @";
                IF COL_LENGTH('dbo.usuarios_usss075826','direccion') IS NULL
                    EXEC('ALTER TABLE dbo.usuarios_usss075826 ADD direccion VARCHAR(85) NULL');
                IF COL_LENGTH('dbo.usuarios_usss075826','telefono') IS NULL
                    EXEC('ALTER TABLE dbo.usuarios_usss075826 ADD telefono VARCHAR(9) NULL');
                IF COL_LENGTH('dbo.usuarios_usss075826','correo') IS NOT NULL
                    EXEC('ALTER TABLE dbo.usuarios_usss075826 ALTER COLUMN correo VARCHAR(max) NULL');";
            using (SqlCommand cmd = new SqlCommand(sql, objConexion))
            {
                cmd.ExecuteNonQuery();
            }
        }

        // Crea el DataSet con los datos de los usuarios (tabla "usuarios")
        public DataSet crearDs()
        {
            objDs.Clear();
            objComando.Connection = objConexion;
            objComando.Parameters.Clear();
            objDataAdapter.SelectCommand = objComando;

            objComando.CommandText = "SELECT idUsuario, usuario, clave, nombre, direccion, telefono FROM usuarios_usss075826 ORDER BY idUsuario";
            objDataAdapter.Fill(objDs, "usuarios");

            return objDs;
        }
        public DataSet obtenerDatos() {
            objDs.Clear();//Limpiar el datase.
            objComando.Connection = objConexion;//Establcer la conexion para ejecutar consultas a la BD

            objDataAdapter.SelectCommand = objComando;

            objComando.CommandText = "SELECT * FROM alumnos";
            objDataAdapter.Fill(objDs, "alumnos"); //tomamos los datos de la BD y llenamos el ds

            objComando.CommandText = "SELECT * FROM materias";
            objDataAdapter.Fill(objDs, "materias");

            return objDs;
        }
        public DataSet obtenerDatos(string consulta)
        {
            objDs.Clear();
            objComando.Connection = objConexion;
            objDataAdapter.SelectCommand = objComando;

            objComando.CommandText = consulta;
            objDataAdapter.Fill(objDs, "datos");

            return objDs;
        }
        public string administrarDatosAlumnos(String[] datos, String accion)
        {
            String sql = "";
            if (accion == "nuevo"){
                sql = "INSERT INTO alumnos(codigo,nombre,direccion,telefono,email) VALUES ('" + datos[1] + "', '" + datos[2] + "', '" + datos[3] + "', '" + datos[4] + "', '" + datos[5] + "')";
            }else if (accion == "modificar"){
                sql = "UPDATE alumnos SET codigo='" + datos[1] + "', nombre='" + datos[2] + "', direccion='" + datos[3] + "', telefono='" + datos[4] + "', email='" + datos[5] + "' WHERE idAlumno='" + datos[0] + "'";
            }else if (accion == "eliminar"){
                sql = "DELETE FROM alumnos WHERE idAlumno='" + datos[0] + "'";
            }
            return ejecutarSQL(sql);
        }
        public string administrarDatosMaterias(String[] datos, String accion){
            String sql = "";
            if (accion == "nuevo"){
                sql = "INSERT INTO materias(codigo,nombre,uv) VALUES ('" + datos[1] + "', '" + datos[2] + "', '" + datos[3] + "')";
            }else if (accion == "modificar"){
                sql = "UPDATE materias SET codigo='" + datos[1] + "', nombre='" + datos[2] + "', uv='" + datos[3] + "' WHERE idMateria='" + datos[0] + "'";
            }else if (accion == "eliminar"){
                sql = "DELETE FROM materias WHERE idMateria='" + datos[0] + "'";
            }
            return ejecutarSQL(sql);
        }
        public String ejecutarSQL(String sql)
        {
            try
            {
                objComando.Connection = objConexion;
                objComando.CommandText = sql;
                objComando.Parameters.Clear();
                return objComando.ExecuteNonQuery().ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        // datos: [0]=idUsuario, [1]=usuario, [2]=clave, [3]=nombre, [4]=direccion, [5]=telefono
        public string mantenimiento_usuarios_usss075826(String[] datos, String accion)
        {
            String sql = "";

            if (accion == "nuevo")
            {
                sql = "INSERT INTO usuarios_usss075826 (usuario, clave, nombre, direccion, telefono) " +
                      "VALUES (@usuario, @clave, @nombre, @direccion, @telefono)";
            }
            else if (accion == "modificar")
            {
                sql = "UPDATE usuarios_usss075826 SET usuario=@usuario, clave=@clave, nombre=@nombre, " +
                      "direccion=@direccion, telefono=@telefono WHERE idUsuario=@id";
            }
            else if (accion == "eliminar")
            {
                sql = "DELETE FROM usuarios_usss075826 WHERE idUsuario=@id";
            }
            else
            {
                return "Accion no valida";
            }

            try
            {
                objComando.Connection = objConexion;
                objComando.CommandText = sql;
                objComando.Parameters.Clear();
                if (accion != "nuevo")
                {
                    objComando.Parameters.AddWithValue("@id", Convert.ToInt32(datos[0]));
                }
                if (accion != "eliminar")
                {
                    objComando.Parameters.AddWithValue("@usuario", datos[1]);
                    objComando.Parameters.AddWithValue("@clave", datos[2]);
                    objComando.Parameters.AddWithValue("@nombre", datos[3]);
                    objComando.Parameters.AddWithValue("@direccion", datos[4]);
                    objComando.Parameters.AddWithValue("@telefono", datos[5]);
                }
                return objComando.ExecuteNonQuery().ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                objComando.Parameters.Clear();
            }
        }

        public bool existeUsuario(string usuario)
        {
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM usuarios_usss075826 WHERE usuario=@u", objConexion))
            {
                cmd.Parameters.AddWithValue("@u", usuario);
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }

        // Valida usuario y clave contra la tabla de usuarios (usado por el login)
        public bool validarLogin(string usuario, string clave)
        {
            // El campo "usuario" guarda el correo. Los errores de BD se propagan para mostrarlos en el login.
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM usuarios_usss075826 WHERE usuario=@u AND clave=@c", objConexion))
            {
                cmd.Parameters.AddWithValue("@u", usuario);
                cmd.Parameters.AddWithValue("@c", clave);
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }
    }
}
