﻿using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace miPrimeaAplicacion
{
    public partial class frmUsuarios : Form
    {
        Conexion objConexion = new Conexion();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        String accion = "nuevo";
        int posicion = 0;

        public frmUsuarios()
        {
            InitializeComponent();
        }

        private void frm_usuarios_Load(object sender, EventArgs e)
        {
            obtenerDatos();
            activarDesactivarCtrls(false);
        }

        // Carga los datos de los usuarios usando el metodo crearDs
        private void obtenerDatos()
        {
            ds = objConexion.crearDs();
            dt = ds.Tables["usuarios"];
            dt.PrimaryKey = new DataColumn[] { dt.Columns["idUsuario"] };

            grdUsuarios.DataSource = dt.DefaultView;
            if (grdUsuarios.Columns.Contains("clave"))
            {
                grdUsuarios.Columns["clave"].Visible = false; // no mostrar claves en la tabla
            }
            if (posicion >= dt.Rows.Count) posicion = dt.Rows.Count - 1;
            if (posicion < 0) posicion = 0;
            mostrarDatos();
        }

        private void mostrarDatos()
        {
            if (dt.Rows.Count > 0)
            {
                DataRow fila = dt.Rows[posicion];
                txtIdUsuario.Text = fila["idUsuario"].ToString();
                txtUsuario.Text = fila["usuario"].ToString();
                txtClave.Text = fila["clave"].ToString();
                txtNombre.Text = fila["nombre"].ToString();
                txtDireccion.Text = fila["direccion"].ToString();
                txtTelefono.Text = fila["telefono"].ToString();
                lblRegistros.Text = (posicion + 1) + " de " + dt.Rows.Count;
                if (grdUsuarios.Rows.Count > posicion)
                {
                    grdUsuarios.ClearSelection();
                    grdUsuarios.Rows[posicion].Selected = true;
                }
            }
            else
            {
                limpiarControles();
                lblRegistros.Text = "0 de 0";
            }
        }

        private void limpiarControles()
        {
            txtIdUsuario.Text = "";
            txtUsuario.Text = "";
            txtClave.Text = "";
            txtNombre.Text = "";
            txtDireccion.Text = "";
            txtTelefono.Text = "";
            lblMensaje.Text = "";
        }

        private void activarDesactivarCtrls(Boolean estado)
        {
            txtUsuario.ReadOnly = !estado;
            txtClave.ReadOnly = !estado;
            txtNombre.ReadOnly = !estado;
            txtDireccion.ReadOnly = !estado;
            txtTelefono.ReadOnly = !estado;
            grbNavegacion.Enabled = !estado;
            grdUsuarios.Enabled = !estado;
            btnEliminar.Enabled = !estado;
            if (estado) txtUsuario.Focus();
        }

        // Validaciones segun la estructura de la tabla
        private bool validarCampos()
        {
            string usuario = txtUsuario.Text.Trim();
            string clave = txtClave.Text.Trim();
            string nombre = txtNombre.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string telefono = txtTelefono.Text.Trim();

            if (usuario == "" || clave == "" || nombre == "" || direccion == "" || telefono == "")
            {
                return error("Complete todos los campos.");
            }
            if (usuario.Length > 35) return error("El correo admite maximo 35 caracteres.");
            if (!Regex.IsMatch(usuario, @"^[^@\s]+@[^@\s]+\.[^@\s]+$")) return error("Ingrese un correo valido.");
            if (clave.Length > 35) return error("La clave admite maximo 35 caracteres.");
            if (nombre.Length > 65) return error("El nombre admite maximo 65 caracteres.");
            if (direccion.Length > 85) return error("La direccion admite maximo 85 caracteres.");
            if (!Regex.IsMatch(telefono, @"^\d{4}-\d{4}$"))
            {
                return error("El telefono debe tener el formato 7777-7777.");
            }
            // usuario unico
            foreach (DataRow fila in dt.Rows)
            {
                if (fila["usuario"].ToString().ToLower() == usuario.ToLower() &&
                    (accion == "nuevo" || fila["idUsuario"].ToString() != txtIdUsuario.Text))
                {
                    return error("El correo '" + usuario + "' ya existe.");
                }
            }
            lblMensaje.Text = "";
            return true;
        }

        private bool error(string mensaje)
        {
            lblMensaje.Text = mensaje;
            return false;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (btnNuevo.Text == "Nuevo")
            {
                btnNuevo.Text = "Guardar";
                btnModificar.Text = "Cancelar";
                accion = "nuevo";
                limpiarControles();
                activarDesactivarCtrls(true);
            }
            else
            { // Guardar
                guardar();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (btnModificar.Text == "Modificar")
            {
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No hay usuarios para modificar.", "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                btnNuevo.Text = "Guardar";
                btnModificar.Text = "Cancelar";
                accion = "modificar";
                activarDesactivarCtrls(true);
            }
            else
            { // Cancelar
                restablecerBotones();
                mostrarDatos();
            }
        }

        private void restablecerBotones()
        {
            activarDesactivarCtrls(false);
            btnNuevo.Text = "Nuevo";
            btnModificar.Text = "Modificar";
            lblMensaje.Text = "";
        }

        private void guardar()
        {
            if (!validarCampos()) return;

            String[] usuario = {
                txtIdUsuario.Text, txtUsuario.Text.Trim(), txtClave.Text.Trim(),
                txtNombre.Text.Trim(), txtDireccion.Text.Trim(), txtTelefono.Text.Trim()
            };
            String respuesta = objConexion.mantenimiento_usuarios_usss075826(usuario, accion);
            if (respuesta != "1")
            {
                MessageBox.Show(respuesta, "Error al guardar usuarios.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            restablecerBotones();
            if (accion == "nuevo") posicion = int.MaxValue; // ir al ultimo registro (el nuevo)
            obtenerDatos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("No hay usuarios para eliminar.", "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Esta seguro de eliminar a " + txtNombre.Text + "?", "Eliminar usuario",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                String[] usuario = { txtIdUsuario.Text, "", "", "", "", "" };
                String respuesta = objConexion.mantenimiento_usuarios_usss075826(usuario, "eliminar");
                if (respuesta != "1")
                {
                    MessageBox.Show(respuesta, "Error al eliminar usuarios.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (posicion > 0) posicion--;
                obtenerDatos();
            }
        }

        private void btnPrimero_Click(object sender, EventArgs e)
        {
            posicion = 0;
            mostrarDatos();
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if (posicion > 0)
            {
                posicion--;
                mostrarDatos();
            }
            else
            {
                MessageBox.Show("Estas en el primer registro.", "Navegacion de Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            if (posicion < dt.Rows.Count - 1)
            {
                posicion++;
                mostrarDatos();
            }
            else
            {
                MessageBox.Show("Estas en el ultimo registro.", "Navegacion de Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnUltimo_Click(object sender, EventArgs e)
        {
            posicion = dt.Rows.Count - 1;
            if (posicion < 0) posicion = 0;
            mostrarDatos();
        }

        private void grdUsuarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dt.Rows.Count)
            {
                posicion = e.RowIndex;
                mostrarDatos();
            }
        }
    }
}
