﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miPrimeaAplicacion
{
    public partial class frmRegistro : Form
    {
        Conexion objConexion = new Conexion();

        public frmRegistro()
        {
            InitializeComponent();
            txtContrasena.PasswordChar = '*';
            MostrarInstrucciones();
        }

        private void MostrarInstrucciones()
        {
            lblMensajeValidacion.ForeColor = Color.Gray;
            // Corregido: Se eliminó el guion (-) que estaba causando error de sintaxis
            lblMensajeValidacion.Text = "• Use un correo válido (entre 6 y 16 caracteres).\n• La contraseña debe incluir letras y números (6 a 16 caracteres).";
        }

        private void btnCrearCuenta_Click(object sender, EventArgs e)
        {
            // 1. Primero capturamos los datos y limpiamos los espacios al inicio y final
            string nombre = txtNombreCompleto.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string usuario = txtUsuario.Text.Trim();
            string pass = txtContrasena.Text.Trim(); // El campo correcto es txtContrasena

            // 2. Verificamos que no haya campos vacíos
            if (nombre == "" || direccion == "" || telefono == "" || usuario == "" || pass == "")
            {
                MostrarError("Por favor, complete todos los campos obligatorios.");
                return;
            }

            // 3. Validación de 6 a 16 caracteres utilizando las variables ya limpias
            if (usuario.Length < 6 || usuario.Length > 16 || pass.Length < 6 || pass.Length > 16)
            {
                MostrarError("El usuario y la contraseña deben tener entre 6 y 16 caracteres.");
                txtUsuario.Focus();
                return;
            }

            // 4. Validar formato de correo electrónico
            if (!System.Text.RegularExpressions.Regex.IsMatch(usuario, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MostrarError("Ingrese un correo válido.");
                txtUsuario.Focus();
                return;
            }

            // 5. Validar longitudes máximas de la base de datos
            if (nombre.Length > 65 || direccion.Length > 85)
            {
                MostrarError("Nombre máx. 65 y dirección máx. 85 caracteres.");
                return;
            }

            // 6. Validar formato exacto del teléfono
            if (!System.Text.RegularExpressions.Regex.IsMatch(telefono, @"^\d{4}-\d{4}$"))
            {
                MostrarError("El teléfono debe tener el formato 7777-7777.");
                txtTelefono.Focus();
                return;
            }

            // 7. Validar que la contraseña contenga al menos una letra y un número
            bool tieneLetra = pass.Any(char.IsLetter);
            bool tieneNumero = pass.Any(char.IsDigit);

            if (!tieneLetra || !tieneNumero)
            {
                MostrarError("La contraseña debe contener obligatoriamente letras y números.");
                txtContrasena.Focus();
                return;
            }

            // 8. Inserción en la base de datos
            try
            {
                if (objConexion.existeUsuario(usuario))
                {
                    MostrarError("Ese correo ya está registrado.");
                    txtUsuario.Focus();
                    return;
                }

                string[] datos = { "", usuario, pass, nombre, direccion, telefono };
                string respuesta = objConexion.mantenimiento_usuarios_usss075826(datos, "nuevo");

                if (respuesta != "1")
                {
                    MostrarError("Error al registrar: " + respuesta);
                    return;
                }

                MessageBox.Show("¡Cuenta creada con éxito!", "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                frmLogin formLogin = new frmLogin();
                formLogin.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MostrarError("Error al registrar: " + ex.Message);
            }
        }

        private void MostrarError(string mensaje)
        {
            lblMensajeValidacion.ForeColor = Color.Red;
            lblMensajeValidacion.Text = mensaje;
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            frmLogin frmLogin = new frmLogin();
            frmLogin.Show();
            this.Hide();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmLogin frmLogin = new frmLogin();
            frmLogin.Show();
            this.Hide();
        }

        private void chkMostrarContrasena_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMostrarContrasena.Checked)
            {
                txtContrasena.PasswordChar = '\0';
            }
            else
            {
                txtContrasena.PasswordChar = '*';
            }
        }
    }
}