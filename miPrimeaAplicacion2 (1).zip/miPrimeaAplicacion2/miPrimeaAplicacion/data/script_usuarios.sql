-- Base de datos: db_academica
-- Tabla de usuarios (codigo de estudiante: usss075826)
-- Nota: la aplicacion tambien crea esta tabla automaticamente si no existe.
USE db_academica;
GO

IF OBJECT_ID('dbo.usuarios_usss075826', 'U') IS NULL
CREATE TABLE dbo.usuarios_usss075826 (
    idUsuario INT IDENTITY(1,1) PRIMARY KEY,   -- int auto_increment
    usuario   VARCHAR(35) NOT NULL,
    clave     VARCHAR(35) NOT NULL,
    nombre    VARCHAR(65) NOT NULL,
    direccion VARCHAR(85) NULL,
    telefono  VARCHAR(9)  NULL
);
GO
